package com.example.homeactivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    ImageView imgProfile;
    TextView txtNickname;
    Button btnLogout, btnDeleteAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        imgProfile = findViewById(R.id.imgProfile);
        txtNickname = findViewById(R.id.txtNickname);
        btnLogout = findViewById(R.id.btnLogout);
        btnDeleteAccount = findViewById(R.id.btnDeleteAccount);

        // 로그인 시 전달되는 "닉네임" 값 예시
        txtNickname.setText("사용자님");

        // ✔ 로그아웃 기능
        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);

            // 이전 액티비티 스택 모두 제거 후 로그인 화면을 새로 띄움
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

            startActivity(intent);
            finish();  // 프로필 화면 종료
        });

        // 회원탈퇴는 이후 서버 연동할 때 구현
        btnDeleteAccount.setOnClickListener(v ->
                txtNickname.setText("회원탈퇴 기능 준비중입니다.")
        );
    }
}
