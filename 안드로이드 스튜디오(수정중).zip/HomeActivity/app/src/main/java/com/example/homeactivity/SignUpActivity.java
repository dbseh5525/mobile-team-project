package com.example.homeactivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    EditText editId, editPw, editEmail, editName, editBirth;
    Button btnSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // XML 연결
        editId = findViewById(R.id.editId);
        editPw = findViewById(R.id.editPw);
        editEmail = findViewById(R.id.editEmail);
        editName = findViewById(R.id.editName);
        editBirth = findViewById(R.id.editBirth);
        btnSignUp = findViewById(R.id.btnSignup);

        // 버튼 클릭 이벤트
        btnSignUp.setOnClickListener(v -> attemptSignUp());
    }

    private void attemptSignUp() {
        String id = editId.getText().toString().trim();
        String pw = editPw.getText().toString().trim();
        String email = editEmail.getText().toString().trim();
        String name = editName.getText().toString().trim();
        String birth = editBirth.getText().toString().trim();

        // 유효성 검사
        if (id.isEmpty() || pw.isEmpty() || email.isEmpty() || name.isEmpty() || birth.isEmpty()) {
            Toast.makeText(this, "모든 정보를 입력해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (birth.length() != 8) {
            Toast.makeText(this, "생년월일은 8자리로 입력해주세요. (예: 20010101)", Toast.LENGTH_SHORT).show();
            return;
        }

        // -------------------------
        // ★ 실제 회원가입 로직 넣는 위치
        // 서버 연동 또는 DB 저장
        // -------------------------

        Toast.makeText(this, "회원가입 완료!", Toast.LENGTH_SHORT).show();

        // 가입 완료 → 로그인 화면으로 돌아가기
        finish();
    }
}
