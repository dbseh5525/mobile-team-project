package com.example.homeactivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout; // LinearLayout을 import 해야 합니다.

import androidx.appcompat.app.AppCompatActivity;

public class LoginHomeActivity extends AppCompatActivity {

    private static final String TAG = "LoginHomeActivity";

    // XML에서 정의된 View들을 선언합니다.
    // 1. 상단 프로필 이미지 (ImageView)
    ImageView ivProfile;

    // 2. 하단 네비게이션 항목들 (LinearLayout - 이 부분이 ClassCastException의 원인이었을 가능성이 높습니다.)
    LinearLayout navHome;
    LinearLayout navMeal;
    LinearLayout navSetting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_home);

        Log.d(TAG, "★★★★ LoginHomeActivity 실행됨! (로그인 성공 후 화면) ★★★★");

        // 1. View 객체 연결 (findViewById)
        // XML ID와 Java 객체 타입을 정확히 일치시킵니다.

        // 상단 프로필 이미지 (ImageView)
        ivProfile = findViewById(R.id.ivProfile);

        // 하단 네비게이션 항목들 (LinearLayout)
        navHome = findViewById(R.id.navHome);
        navMeal = findViewById(R.id.navMeal);
        navSetting = findViewById(R.id.navSetting);

        // 2. 이벤트 리스너 설정 (예시: 프로필 이미지 클릭 시 ProfileActivity로 이동)
        if (ivProfile != null) {
            ivProfile.setOnClickListener(v -> {
                Log.d(TAG, "프로필 이미지 클릭됨");
                // 프로필 화면으로 이동 (ProfileActivity가 등록되어 있어야 합니다)
                startActivity(new Intent(LoginHomeActivity.this, ProfileActivity.class));
            });
        }

        // 예시: 식단관리 탭 클릭 시 MealRegisterActivity로 이동
        if (navMeal != null) {
            navMeal.setOnClickListener(v -> {
                Log.d(TAG, "식단관리 탭 클릭됨");
                startActivity(new Intent(LoginHomeActivity.this, MealRegisterActivity.class));
            });
        }

        // 예시: 사용자 설정 탭 클릭 시 UserSettingActivity로 이동
        if (navSetting != null) {
            navSetting.setOnClickListener(v -> {
                Log.d(TAG, "사용자 설정 탭 클릭됨");
                startActivity(new Intent(LoginHomeActivity.this, UserSettingActivity.class));
            });
        }

        // 현재 화면 (홈)은 navHome 클릭 리스너를 별도로 설정하지 않아도 됩니다.
    }
}