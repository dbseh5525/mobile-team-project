package com.example.homeactivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UserSettingActivity extends AppCompatActivity {

    ImageView imgProfile;
    TextView txtNickname, btnBack;
    EditText editHeight, editWeight, editTargetWeight, editAllergy, editDisease;
    Button btnDiet, btnMuscle, btnSave;
    Spinner spinnerPeriod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_setting);

        // ----------------------
        // XML 연결
        // ----------------------
        imgProfile = findViewById(R.id.imgProfile);
        txtNickname = findViewById(R.id.txtNickname);
        btnBack = findViewById(R.id.btnBack);

        editHeight = findViewById(R.id.editHeight);
        editWeight = findViewById(R.id.editWeight);
        editTargetWeight = findViewById(R.id.editTargetWeight);
        editAllergy = findViewById(R.id.editAllergy);
        editDisease = findViewById(R.id.editDisease);

        btnDiet = findViewById(R.id.btnDiet);
        btnMuscle = findViewById(R.id.btnMuscle);
        btnSave = findViewById(R.id.btnSave);

        spinnerPeriod = findViewById(R.id.spinnerPeriod);

        // ----------------------
        // 닉네임 예시 (나중에 로그인 정보 연동 가능)
        // ----------------------
        txtNickname.setText("닉네임");

        // ----------------------
        // Spinner 드롭다운 커스텀 적용
        // ----------------------
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                R.layout.dropdown_item,   // 리스트 아이템 UI
                new String[]{"2주", "1개월", "3개월", "6개월", "1년"}
        );

        adapter.setDropDownViewResource(R.layout.dropdown_item);
        spinnerPeriod.setAdapter(adapter);

        // ----------------------
        // 뒤로가기 버튼
        // ----------------------
        btnBack.setOnClickListener(v -> finish());

        // ----------------------
        // 모드 선택 버튼
        // ----------------------
        btnDiet.setOnClickListener(v -> {
            btnDiet.setBackgroundColor(0xFFC8F7C5);   // 선택 색
            btnMuscle.setBackgroundColor(0xFFEEEEEE); // 비활성 색
        });

        btnMuscle.setOnClickListener(v -> {
            btnMuscle.setBackgroundColor(0xFFC8F7C5);
            btnDiet.setBackgroundColor(0xFFEEEEEE);
        });

        // ----------------------
        // 저장 버튼
        // ----------------------
        btnSave.setOnClickListener(v -> {
            Toast.makeText(this, "저장되었습니다.", Toast.LENGTH_SHORT).show();
        });
    }
}
