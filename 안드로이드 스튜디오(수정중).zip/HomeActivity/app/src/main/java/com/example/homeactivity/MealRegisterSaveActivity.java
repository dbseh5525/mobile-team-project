package com.example.homeactivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MealRegisterSaveActivity extends AppCompatActivity {

    Button btnSave, btnMorning, btnLunch, btnDinner;
    EditText editFoodName, editCalorie, editCarb, editProtein, editFat;

    String selectedMeal = "아침"; // 기본값

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_register_save);

        // ▼ 버튼 연결
        btnSave = findViewById(R.id.btnSave);
        btnMorning = findViewById(R.id.btnMorning);
        btnLunch = findViewById(R.id.btnLunch);
        btnDinner = findViewById(R.id.btnDinner);

        // ▼ EditText 연결
        editFoodName = findViewById(R.id.editFoodName);
        editCalorie = findViewById(R.id.editCalorie);
        editCarb = findViewById(R.id.editCarb);
        editProtein = findViewById(R.id.editProtein);
        editFat = findViewById(R.id.editFat);

        // ▼ 식사 버튼 선택 기능
        btnMorning.setOnClickListener(v -> selectMeal("아침"));
        btnLunch.setOnClickListener(v -> selectMeal("점심"));
        btnDinner.setOnClickListener(v -> selectMeal("저녁"));

        // ▼ 저장 버튼 클릭
        btnSave.setOnClickListener(v -> saveMeal());
    }

    // ---------------------------------------------------------
    // ▶▶ 식사 선택 함수
    // ---------------------------------------------------------
    private void selectMeal(String meal) {
        selectedMeal = meal;

        // 버튼 UI 변경
        btnMorning.setBackgroundResource(
                meal.equals("아침") ? R.drawable.meal_button_selected : R.drawable.meal_button_unselected
        );
        btnLunch.setBackgroundResource(
                meal.equals("점심") ? R.drawable.meal_button_selected : R.drawable.meal_button_unselected
        );
        btnDinner.setBackgroundResource(
                meal.equals("저녁") ? R.drawable.meal_button_selected : R.drawable.meal_button_unselected
        );
    }

    // ---------------------------------------------------------
    // ▶▶ 저장 기능
    // ---------------------------------------------------------
    private void saveMeal() {

        // 입력값 가져오기
        String food = editFoodName.getText().toString().trim();
        String calorie = editCalorie.getText().toString().trim();
        String carb = editCarb.getText().toString().trim();
        String protein = editProtein.getText().toString().trim();
        String fat = editFat.getText().toString().trim();

        if (food.isEmpty()) {
            Toast.makeText(this, "음식명을 입력하세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        // SharedPreferences 저장
        SharedPreferences prefs = getSharedPreferences("mealData", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putString(selectedMeal + "_food", food);
        editor.putString(selectedMeal + "_calorie", calorie);
        editor.putString(selectedMeal + "_carb", carb);
        editor.putString(selectedMeal + "_protein", protein);
        editor.putString(selectedMeal + "_fat", fat);

        editor.apply();

        Toast.makeText(this, "저장되었습니다.", Toast.LENGTH_SHORT).show();

        // 저장 후 다시 등록 화면으로 이동
        Intent intent = new Intent(MealRegisterSaveActivity.this, MealRegisterActivity.class);
        startActivity(intent);

        finish();
    }
}
