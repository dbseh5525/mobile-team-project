package com.example.homeactivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MealSearchActivity extends AppCompatActivity {

    LinearLayout mainLayout;

    Button btnMorning, btnLunch, btnDinner;

    TextView txtFoodName, txtCalorie, txtCarb, txtProtein, txtFat;

    TextView tabRegister, tabSearch, tabRecommend;

    ImageView navHome, navMeal, navSetting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /** 🔥🔥 여기 바꿔야 함! 🔥🔥 */
        setContentView(R.layout.activity_meal_search);

        // Blur 적용용 최상단 레이아웃
        mainLayout = findViewById(R.id.mainLayout);

        // 버튼·텍스트 연결
        btnMorning = findViewById(R.id.btnMorning);
        btnLunch   = findViewById(R.id.btnLunch);
        btnDinner  = findViewById(R.id.btnDinner);

        txtFoodName = findViewById(R.id.txtFoodName);
        txtCalorie  = findViewById(R.id.txtCalorie);
        txtCarb     = findViewById(R.id.txtCarb);
        txtProtein  = findViewById(R.id.txtProtein);
        txtFat      = findViewById(R.id.txtFat);

        tabRegister = findViewById(R.id.tabRegister);
        tabSearch   = findViewById(R.id.tabSearch);
        tabRecommend= findViewById(R.id.tabRecommend);

        navHome     = findViewById(R.id.navHome);
        navMeal     = findViewById(R.id.navMeal);
        navSetting  = findViewById(R.id.navSetting);

        // 식사 버튼 클릭 → 날짜 선택
        View.OnClickListener mealClick = v -> showDatePicker();
        btnMorning.setOnClickListener(mealClick);
        btnLunch.setOnClickListener(mealClick);
        btnDinner.setOnClickListener(mealClick);

        // 상단 탭 이동
        tabRegister.setOnClickListener(v ->
                startActivity(new Intent(MealSearchActivity.this, MealRegisterActivity.class)));

        tabSearch.setOnClickListener(v -> {
            // 이미 현재 페이지
        });

        tabRecommend.setOnClickListener(v ->
                startActivity(new Intent(MealSearchActivity.this, MealRecommendActivity.class)));

        // 하단 네비게이션
        navHome.setOnClickListener(v ->
                startActivity(new Intent(MealSearchActivity.this, HomeActivity.class)));

        navMeal.setOnClickListener(v -> {
            // 현재 페이지
        });

        navSetting.setOnClickListener(v ->
                startActivity(new Intent(MealSearchActivity.this, UserSettingActivity.class)));
    }

    private void showDatePicker() {
        applyBlur(true);

        Calendar cal = Calendar.getInstance();

        DatePickerDialog dialog = new DatePickerDialog(
                MealSearchActivity.this,
                (view, year, month, day) -> {
                    txtFoodName.setText("음식명 : 시리얼");
                    txtCalorie.setText("칼로리 : 800 kcal");
                    txtCarb.setText("탄수화물 : 115g");
                    txtProtein.setText("단백질 : 30g");
                    txtFat.setText("지방 : 22g");
                    applyBlur(false);
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
        );

        dialog.setOnCancelListener(d -> applyBlur(false));
        dialog.show();
    }

    private void applyBlur(boolean enable) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            mainLayout.setRenderEffect(
                    enable ? RenderEffect.createBlurEffect(20f, 20f, Shader.TileMode.CLAMP) : null
            );
        }
    }
}
