package com.example.homeactivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log; // Log 사용을 위해 추가
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity"; // Log 태그 정의

    EditText editId, editPassword;
    Button btnLogin;
    TextView txtSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 1. View 객체 연결 (ID가 정확해야 합니다!)
        editId = findViewById(R.id.editId);
        editPassword = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.btnLogin);
        txtSignUp = findViewById(R.id.txtSignUp);

        // --- ★★★ 버튼 연결 성공 여부 확인 ★★★ ---
        if (btnLogin == null) {
            Log.e(TAG, "btnLogin 연결 실패: activity_login.xml의 ID를 확인하세요.");
            Toast.makeText(this, "오류: 로그인 버튼을 찾을 수 없습니다.", Toast.LENGTH_LONG).show();
            return; // 연결 실패 시 이후 코드를 실행하지 않습니다.
        }
        // ----------------------------------------

        // 2. 로그인 버튼 클릭 리스너
        btnLogin.setOnClickListener(v -> {
            Log.d(TAG, "로그인 버튼 클릭됨"); // 버튼이 눌리는지 확인
            doLogin();
        });

        // 3. 회원가입 이동
        if (txtSignUp != null) {
            txtSignUp.setOnClickListener(v -> {
                Log.d(TAG, "회원가입 텍스트 클릭됨");
                startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
            });
        }
    }

    private void doLogin() {
        String id = editId.getText().toString().trim();
        String pw = editPassword.getText().toString().trim();

        Log.d(TAG, "입력 ID: " + id + ", 입력 PW: " + pw); // 입력 값 확인

        if (id.isEmpty() || pw.isEmpty()) {
            Toast.makeText(this, "ID와 PASSWORD를 입력하세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        // 테스트용 로그인
        // 조건: id는 "test", pw는 "1234"
        if (id.equals("test") && pw.equals("1234")) {
            Log.i(TAG, "로그인 성공! 홈 화면으로 이동.");
            Toast.makeText(this, "로그인 성공!", Toast.LENGTH_SHORT).show();

            // ★★★ 로그인 후 홈 화면으로 이동 ★★★
            Intent intent = new Intent(LoginActivity.this, LoginHomeActivity.class);
            startActivity(intent);

            finish(); // 현재 로그인 화면 종료
        } else {
            Log.w(TAG, "로그인 실패: ID 또는 PW 불일치.");
            Toast.makeText(this, "로그인 정보가 올바르지 않습니다.", Toast.LENGTH_SHORT).show();
        }
    }
}