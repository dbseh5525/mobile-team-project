package com.example.homeactivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private Button btnMorning, btnLunch, btnDinner;
    private ImageView btnProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnMorning = findViewById(R.id.btnMorning);
        btnLunch = findViewById(R.id.btnLunch);
        btnDinner = findViewById(R.id.btnDinner);
        btnProfile = findViewById(R.id.btnProfile);

        // 로그인 전이므로 무조건 “로그인 필요” 메시지
        btnMorning.setOnClickListener(v ->
                Toast.makeText(this, "로그인 후 이용 가능합니다.", Toast.LENGTH_SHORT).show());

        btnLunch.setOnClickListener(v ->
                Toast.makeText(this, "로그인 후 이용 가능합니다.", Toast.LENGTH_SHORT).show());

        btnDinner.setOnClickListener(v ->
                Toast.makeText(this, "로그인 후 이용 가능합니다.", Toast.LENGTH_SHORT).show());

        // 프로필 버튼 → 로그인 화면으로 이동
        btnProfile.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            startActivity(intent);
        });
    }
}
