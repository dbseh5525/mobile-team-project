package com.example.homeactivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MealRegisterActivity extends AppCompatActivity {

    Button btnMorning, btnLunch, btnDinner;
    TextView txtFoodName, txtCalorie, txtCarb, txtProtein, txtFat;

    String selectedMeal = "아침";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_register);

        // 버튼 연결
        btnMorning = findViewById(R.id.btnMorning);
        btnLunch = findViewById(R.id.btnLunch);
        btnDinner = findViewById(R.id.btnDinner);

        txtFoodName = findViewById(R.id.txtFoodName);
        txtCalorie = findViewById(R.id.txtCalorie);
        txtCarb = findViewById(R.id.txtCarb);
        txtProtein = findViewById(R.id.txtProtein);
        txtFat = findViewById(R.id.txtFat);

        // -------------------------------
        // ⭐ 탭 이동 기능
        // -------------------------------
        TextView tabRegister = findViewById(R.id.tabRegister);
        TextView tabSearch = findViewById(R.id.tabSearch);
        TextView tabRecommend = findViewById(R.id.tabRecommend);

        // 식단등록 → 자기 자신(새로고침 방지)
        tabRegister.setOnClickListener(v -> {
            // 아무것도 안함
        });

        // 식단조회 탭 → ★ 여기가 문제였음! activity_meal_search 로 이동!
        tabSearch.setOnClickListener(v -> {
            Intent intent = new Intent(MealRegisterActivity.this, MealSearchActivity.class);
            startActivity(intent);
        });

        // 식단추천 탭 → 추천 페이지로 이동
        tabRecommend.setOnClickListener(v -> {
            Intent intent = new Intent(MealRegisterActivity.this, MealRecommendActivity.class);
            startActivity(intent);
        });


        // -------------------------------
        // 기본값 아침 자동로드
        // -------------------------------
        highlightButton();
        loadMealData("아침");

        btnMorning.setOnClickListener(v -> {
            selectedMeal = "아침";
            highlightButton();
            loadMealData("아침");
        });

        btnLunch.setOnClickListener(v -> {
            selectedMeal = "점심";
            highlightButton();
            loadMealData("점심");
        });

        btnDinner.setOnClickListener(v -> {
            selectedMeal = "저녁";
            highlightButton();
            loadMealData("저녁");
        });
    }

    private void highlightButton() {
        btnMorning.setBackgroundResource(selectedMeal.equals("아침") ?
                R.drawable.meal_button_selected : R.drawable.meal_button_unselected);

        btnLunch.setBackgroundResource(selectedMeal.equals("점심") ?
                R.drawable.meal_button_selected : R.drawable.meal_button_unselected);

        btnDinner.setBackgroundResource(selectedMeal.equals("저녁") ?
                R.drawable.meal_button_selected : R.drawable.meal_button_unselected);
    }


    private void loadMealData(String meal) {

        SharedPreferences prefs = getSharedPreferences("mealData", MODE_PRIVATE);

        String food = prefs.getString(meal + "_food", "");
        String calorie = prefs.getString(meal + "_calorie", "");
        String carb = prefs.getString(meal + "_carb", "");
        String protein = prefs.getString(meal + "_protein", "");
        String fat = prefs.getString(meal + "_fat", "");

        txtFoodName.setText("음식명 : " + food);
        txtCalorie.setText("칼로리 : " + calorie);
        txtCarb.setText("탄수화물 : " + carb);
        txtProtein.setText("단백질 : " + protein);
        txtFat.setText("지방 : " + fat);
    }
}
