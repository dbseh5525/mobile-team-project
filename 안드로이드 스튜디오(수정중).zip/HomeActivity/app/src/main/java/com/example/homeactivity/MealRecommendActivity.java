package com.example.homeactivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MealRecommendActivity extends AppCompatActivity {

    TextView tabRegister, tabSearch, tabRecommend;
    ImageView navHome, navMeal, navSetting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_recommend);

        tabRegister = findViewById(R.id.tabRegister);
        tabSearch = findViewById(R.id.tabSearch);
        tabRecommend = findViewById(R.id.tabRecommend);

        navHome = findViewById(R.id.navHome);
        navMeal = findViewById(R.id.navMeal);
        navSetting = findViewById(R.id.navSetting);

        // 탭 이동
        tabRegister.setOnClickListener(v ->
                startActivity(new Intent(this, MealRegisterSaveActivity.class)));

        tabSearch.setOnClickListener(v ->
                startActivity(new Intent(this, MealSearchActivity.class)));

        // 하단 네비
        navHome.setOnClickListener(v ->
                startActivity(new Intent(this, HomeActivity.class)));

        navMeal.setOnClickListener(v -> {
            // 현재 식단관리 탭 → 아무 동작 안하게 해도 ok
        });

        navSetting.setOnClickListener(v ->
                startActivity(new Intent(this, UserSettingActivity.class)));
    }
}
